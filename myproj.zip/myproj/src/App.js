import logo from "./logo.svg";
import "./App.css";
import { Provider } from "react-redux";
import AppRoute from "./Router/AppRoute";
import { createStore } from "redux";
import store from "./store/store";
import { BrowserRouter } from "react-router-dom";
import "./styles/main.bundle.css";

function App() {
  return (
    <Provider store={store}>
      <AppRoute />
    </Provider>
  );
}

export default App;
