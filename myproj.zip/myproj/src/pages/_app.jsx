/* import React from "react";

import Routes from "./_routes";

const App = () => {
  return <Routes />;
};

export default App; */
