import React from 'react';

import {DashboardLayout} from '../components/Layout';

const TeamsPage = () => {
  return (
    <DashboardLayout>
      <h2>Teams Page</h2>
    </DashboardLayout>
  )
}

export default TeamsPage;