import React from "react";
import { Route, Switch, BrowserRouter } from "react-router-dom";
import login from "../Login/login";
import dashboard from "../dashboard/dashboard";
import { connect } from "react-redux";

import SettingsPage from "../pages/settings";
import ProjectsPage from "../pages/projects";
import MembersPage from "../pages/members";
import AboutPage from "../pages/about";
import TeamsPage from "../pages/teams";
import HomePage from "../pages/home";
class AppRoute extends React.Component {
  render() {
    return (
      <div>
        <BrowserRouter>
          <Switch>
            <Route path="/login" component={login} />
            <Route path="/dashboard" component={dashboard} />

            <Route path="/login" component={login} />
            <Route path="/about/members" component={MembersPage} />

            <Route path="/about/projects" component={ProjectsPage} />
            <Route path="/about" component={AboutPage} />

            <Route path="/another/teams" component={TeamsPage} />

            <Route path="/settings" component={SettingsPage} />
            <Route path="/home" component={HomePage} />

            <Route path="/" component={login} />
          </Switch>
        </BrowserRouter>
      </div>
    );
  }
}

const mapStateToProps = (store) => {
  return {};
};

export default connect(mapStateToProps)(AppRoute);
