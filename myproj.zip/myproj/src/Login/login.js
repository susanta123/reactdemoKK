import React, { Component } from "react";
import "../App.css";
import { InputText } from "primereact/inputtext";
import "react-toastify/dist/ReactToastify.css";
import { toast } from "react-toastify";
toast.configure();
export default class login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      password: "",
    };
  }

  saveData = () => {
    const name = this.state.name;
    const password = this.state.password;

    if (name !== "" && password !== "") {
      localStorage.setItem("Name", name);
      localStorage.setItem("Password", password);
      toast.success("Login Successfully", {
        position: toast.POSITION.TOP_CENTER,
      });

      this.props.history.push("/dashboard");
    } else {
      toast.error("Please Enter User Name and password", {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  };

  render() {
    return (
      /*       <div>
        <div className="fullName">
          <label htmlFor="fullName">Full Name</label>
          <InputText
            type="text"
            value={this.state.name}
            id="name"
            onChange={(e) => this.setState({ name: e.target.value })}
          />
        </div>

        <div className="password">
          <label htmlFor="password">Password</label>
          <InputText
            type="password"
            value={this.state.password}
            id="password"
            onChange={(e) => this.setState({ password: e.target.value })}
          />
        </div>
        <div className="submit">
          <button onClick={this.saveData}>Submit</button>
        </div>
      </div> */

      <div className="App">
        <form className="form" onSubmit={this.saveData}>
          <div className="input-group">
            <label htmlFor="email" style={{ marginRight: "27px" }}>
              User Name
            </label>
            <input
              type="email"
              name="email"
              value={this.state.name}
              onChange={(e) => this.setState({ name: e.target.value })}
              placeholder="nome@email.com.br"
            />
          </div>
          <br></br>
          <div className="input-group">
            <label htmlFor="password" style={{ marginRight: "27px" }}>
              password
            </label>
            <input
              type="password"
              value={this.state.password}
              id="password"
              name="password"
              onChange={(e) => this.setState({ password: e.target.value })}
            />
          </div>
          <button
            className="primary"
            style={{
              backgroundColor: "blue",
              color: "aliceblue",
              width: "103px",
              marginTop: "29px",
              position: "fixed",
              marginLeft: "-33px",
            }}
          >
            Submit
          </button>
        </form>
      </div>
    );
  }
}
