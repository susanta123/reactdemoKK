import React from "react";

import { DashboardLayout } from "../components/Layout";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
const useStyles = makeStyles((theme) => ({
  paper: {
    padding: theme.spacing(1),
    textAlign: "center",
    padding: "48px",
    backgroundColor: "#7596d7",
    color: theme.palette.text.secondary,
  },
}));
function GridItem({ classes }) {
  return (
    // From 0 to 600px wide (smart-phones), I take up 12 columns, or the whole device width!
    // From 600-690px wide (tablets), I take up 6 out of 12 columns, so 2 columns fit the screen.
    // From 960px wide and above, I take up 25% of the device (3/12), so 4 columns fit the screen.
    <Grid item xs={12} sm={6} md={3}>
      <Paper className={classes.paper}>item</Paper>
    </Grid>
  );
}

const HomePage = () => {
  const classes = useStyles();

  return (
    <DashboardLayout>
      <h2>Home Page</h2>
      <Grid container spacing={1}>
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
        <GridItem classes={classes} />
      </Grid>
    </DashboardLayout>
  );
};

export default HomePage;
